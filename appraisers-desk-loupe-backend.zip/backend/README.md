# The Appraiser's Desk & Loupe — API

## What this is
A Node/Express backend that:
- Handles signup/login (`/api/auth`)
- Runs real photo identification through Claude's vision model (`/api/identify`)
- Enforces plan limits (free tier: 3/month) and logs usage
- Handles Stripe subscriptions and webhooks (`/api/billing`)

## Local setup
```bash
npm install
cp .env.example .env   # then fill in real values
npm run migrate        # applies db/schema.sql to your database
npm start
```

## Deploying to Render (the database is already live)
1. Push this folder to a new GitHub repository.
2. In the Render dashboard, or by asking Claude, create a **Web Service** pointing at that repo:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
3. Add these Environment Variables on the service (Render dashboard → Environment):
   - `DATABASE_URL` — the **Internal** Database URL from your `appraisers-desk-loupe-db` Postgres instance (same Render account, so internal networking is free and fast)
   - `ANTHROPIC_API_KEY`
   - `JWT_SECRET`
   - `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`
   - `APP_URL` — wherever the frontend ends up hosted
4. After the first deploy, run the migration once: Render dashboard → Shell tab → `npm run migrate`.
5. In Stripe: create two Products/Prices (Journeyman $9/mo, Master $24/mo), then update the `plans` table's `stripe_price_id` column with the real Price IDs.
6. In Stripe: add a webhook endpoint pointing at `https://your-service.onrender.com/api/billing/webhook`, subscribed to `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`.

## Connecting the frontend
The current frontend (the published artifact) uses hardcoded mock data. To go live, it needs:
- A login/signup form calling `POST /api/auth/signup` and `/login`, storing the returned token
- The "Examine this piece" button sending the photo to `POST /api/identify` (as `multipart/form-data`, fields: `image`, `mode`) with `Authorization: Bearer <token>`, instead of the local mock
- The membership "Upgrade" buttons calling `POST /api/billing/create-checkout-session` and redirecting to the returned Stripe URL

Happy to build that connected frontend next.
