const express = require('express');
const multer = require('multer');
const Anthropic = require('@anthropic-ai/sdk');
const pool = require('../db/pool');
const { requireAuth } = require('./auth');

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

const FINE_PROMPT = `Analyze this jewelry image. Return ONLY valid JSON, no other text, matching exactly this structure:
{
  "category": "string (ring, necklace, bracelet, earrings, etc.)",
  "metal": { "type": "string", "purity": "string or null", "confidence": number },
  "gemstones": [{ "type": "string", "estimated_carat": number or null, "cut": "string or null", "confidence": number }],
  "hallmarks": [{ "mark": "string", "likely_meaning": "string or null" }],
  "style_era": "string or null",
  "estimated_value_low_usd": number or null,
  "estimated_value_high_usd": number or null,
  "overall_confidence": number,
  "disclaimer": "string"
}`;

const COSTUME_PROMPT = `Analyze this vintage costume jewelry image. Focus especially on identifying the maker's signature/mark, construction style, and era. Return ONLY valid JSON, no other text, matching exactly this structure:
{
  "category": "string (brooch, necklace, clip earrings, bracelet, etc.)",
  "maker_signature": "string — the maker's mark if legible, or 'Unsigned, attributed to ...' or 'Unsigned, unattributed'",
  "metal": { "type": "string (e.g. gold-tone base metal, rhodium-plated)", "confidence": number },
  "gemstones": [{ "type": "string (e.g. paste, rhinestone, glass)", "confidence": number }],
  "hallmarks": [{ "mark": "string", "likely_meaning": "string or null" }],
  "style_era": "string or null",
  "estimated_value_low_usd": number or null,
  "estimated_value_high_usd": number or null,
  "overall_confidence": number,
  "disclaimer": "string"
}`;

function stripCodeFences(text) {
  return text.replace(/```json\s*|```/g, '').trim();
}

router.post('/', requireAuth, upload.single('image'), async (req, res) => {
  const mode = req.body.mode === 'costume' ? 'costume' : 'fine';
  if (!req.file) return res.status(400).json({ error: 'No image uploaded.' });

  try {
    // --- Enforce plan limits ---
    const subResult = await pool.query(
      `SELECT s.plan_id, p.monthly_id_limit FROM subscriptions s
       JOIN plans p ON p.id = s.plan_id
       WHERE s.user_id = $1 AND s.status = 'active'
       ORDER BY s.created_at DESC LIMIT 1`,
      [req.userId]
    );
    const plan = subResult.rows[0];
    if (!plan) return res.status(403).json({ error: 'No active plan found.' });

    if (plan.monthly_id_limit !== null) {
      const periodStart = new Date();
      periodStart.setDate(1);
      const usageResult = await pool.query(
        `SELECT identification_count FROM usage_counters WHERE user_id = $1 AND period_start = $2`,
        [req.userId, periodStart.toISOString().slice(0, 10)]
      );
      const used = usageResult.rows[0]?.identification_count || 0;
      if (used >= plan.monthly_id_limit) {
        return res.status(403).json({
          error: `You've used all ${plan.monthly_id_limit} identifications on your plan this month. Upgrade for unlimited access.`
        });
      }
    }

    // --- Call Claude with vision ---
    const base64Image = req.file.buffer.toString('base64');
    const prompt = mode === 'costume' ? COSTUME_PROMPT : FINE_PROMPT;

    const response = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: req.file.mimetype, data: base64Image } },
          { type: 'text', text: prompt }
        ]
      }]
    });

    const textBlock = response.content.find(b => b.type === 'text');
    const parsed = JSON.parse(stripCodeFences(textBlock.text));

    // --- Store the result ---
    const gem = parsed.gemstones?.[0];
    const hallmark = parsed.hallmarks?.[0]?.mark || null;

    const insertResult = await pool.query(
      `INSERT INTO identifications
        (user_id, mode, image_url, category, metal, purity, gemstone, estimated_carat,
         maker_signature, hallmark, style_era, estimated_value_low, estimated_value_high,
         overall_confidence, raw_model_response)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       RETURNING id, created_at`,
      [
        req.userId, mode, 'not-stored-in-demo', parsed.category, parsed.metal?.type,
        parsed.metal?.purity || null, gem?.type || null, gem?.estimated_carat || null,
        parsed.maker_signature || null, hallmark, parsed.style_era,
        parsed.estimated_value_low_usd ? parsed.estimated_value_low_usd * 100 : null,
        parsed.estimated_value_high_usd ? parsed.estimated_value_high_usd * 100 : null,
        parsed.overall_confidence, JSON.stringify(parsed)
      ]
    );

    // --- Bump usage counter (only matters for capped plans) ---
    const periodStart = new Date();
    periodStart.setDate(1);
    await pool.query(
      `INSERT INTO usage_counters (user_id, period_start, identification_count)
       VALUES ($1, $2, 1)
       ON CONFLICT (user_id, period_start)
       DO UPDATE SET identification_count = usage_counters.identification_count + 1`,
      [req.userId, periodStart.toISOString().slice(0, 10)]
    );

    res.json({ id: insertResult.rows[0].id, created_at: insertResult.rows[0].created_at, ...parsed });
  } catch (err) {
    console.error(err);
    if (err instanceof SyntaxError) {
      return res.status(502).json({ error: 'Could not parse the analysis. Please try again.' });
    }
    res.status(500).json({ error: 'Something went wrong analyzing this image.' });
  }
});

router.get('/history', requireAuth, async (req, res) => {
  const result = await pool.query(
    `SELECT id, mode, category, metal, gemstone, maker_signature, hallmark,
            style_era, estimated_value_low, estimated_value_high, overall_confidence, created_at
     FROM identifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`,
    [req.userId]
  );
  res.json(result.rows);
});

module.exports = router;
