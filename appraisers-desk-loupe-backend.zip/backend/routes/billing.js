const express = require('express');
const Stripe = require('stripe');
const pool = require('../db/pool');
const { requireAuth } = require('./auth');

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Creates a Stripe Checkout session for upgrading to a paid plan.
// Frontend redirects the browser to the returned `url`.
router.post('/create-checkout-session', requireAuth, async (req, res) => {
  const { planId } = req.body; // 'journeyman' or 'master'
  try {
    const planResult = await pool.query('SELECT * FROM plans WHERE id = $1', [planId]);
    const plan = planResult.rows[0];
    if (!plan || !plan.stripe_price_id) {
      return res.status(400).json({ error: 'Unknown or unconfigured plan.' });
    }

    const userResult = await pool.query('SELECT * FROM users WHERE id = $1', [req.userId]);
    const user = userResult.rows[0];

    let customerId = user.stripe_customer_id;
    if (!customerId) {
      const customer = await stripe.customers.create({ email: user.email });
      customerId = customer.id;
      await pool.query('UPDATE users SET stripe_customer_id = $1 WHERE id = $2', [customerId, user.id]);
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      mode: 'subscription',
      line_items: [{ price: plan.stripe_price_id, quantity: 1 }],
      success_url: `${process.env.APP_URL}/billing/success`,
      cancel_url: `${process.env.APP_URL}/billing/canceled`,
      metadata: { userId: user.id, planId }
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not start checkout.' });
  }
});

// Stripe webhook — keeps the `subscriptions` table in sync with what
// actually happened in Stripe. Register this URL in the Stripe dashboard.
// IMPORTANT: this route needs the raw request body, so it's mounted with
// express.raw() in server.js, not express.json().
router.post('/webhook', async (req, res) => {
  const sig = req.headers['stripe-signature'];
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const subscription = await stripe.subscriptions.retrieve(session.subscription);
        await upsertSubscription(session.metadata.userId, session.metadata.planId, subscription);
        break;
      }
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        const userResult = await pool.query('SELECT id FROM users WHERE stripe_customer_id = $1', [subscription.customer]);
        const user = userResult.rows[0];
        if (user) {
          const planId = subscription.items.data[0]?.price?.lookup_key || undefined;
          await upsertSubscription(user.id, planId, subscription);
        }
        break;
      }
    }
    res.json({ received: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Webhook handling failed.' });
  }
});

async function upsertSubscription(userId, planId, stripeSub) {
  await pool.query(
    `INSERT INTO subscriptions
       (user_id, plan_id, stripe_subscription_id, status, current_period_start, current_period_end, cancel_at_period_end)
     VALUES ($1, COALESCE($2, 'journeyman'), $3, $4, to_timestamp($5), to_timestamp($6), $7)
     ON CONFLICT (stripe_subscription_id)
     DO UPDATE SET status = $4, current_period_start = to_timestamp($5),
                    current_period_end = to_timestamp($6), cancel_at_period_end = $7, updated_at = now()`,
    [
      userId, planId, stripeSub.id, stripeSub.status,
      stripeSub.current_period_start, stripeSub.current_period_end, stripeSub.cancel_at_period_end
    ]
  );
}

module.exports = router;
