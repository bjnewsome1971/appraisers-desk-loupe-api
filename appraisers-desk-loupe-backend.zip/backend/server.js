require('dotenv').config();
const express = require('express');
const cors = require('cors');

const { router: authRouter } = require('./routes/auth');
const identifyRouter = require('./routes/identify');
const billingRouter = require('./routes/billing');

const app = express();

app.use(cors());

// Stripe webhook needs the raw body for signature verification,
// so it gets express.raw() instead of express.json(), applied before
// the general JSON parser below.
app.use('/api/billing/webhook', express.raw({ type: 'application/json' }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRouter);
app.use('/api/identify', identifyRouter);
app.use('/api/billing', billingRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Appraiser's Desk & Loupe API running on port ${PORT}`));
