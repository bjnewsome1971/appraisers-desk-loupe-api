const { Pool } = require('pg');

// DATABASE_URL comes from Render (Internal Database URL, if the API
// also runs on Render — that's free and faster than the External URL).
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('render.com')
    ? { rejectUnauthorized: false }
    : false
});

module.exports = pool;
