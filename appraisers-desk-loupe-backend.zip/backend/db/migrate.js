// Run with: npm run migrate
// Applies schema.sql to whatever DATABASE_URL points at.
// Safe to re-run: wrap statements in IF NOT EXISTS where possible,
// or drop the tables first in a throwaway environment.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const pool = require('./pool');

async function migrate() {
  const sql = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  const client = await pool.connect();
  try {
    await client.query(sql);
    console.log('Schema applied successfully.');
  } catch (err) {
    console.error('Migration failed:', err.message);
    process.exitCode = 1;
  } finally {
    client.release();
    await pool.end();
  }
}

migrate();
