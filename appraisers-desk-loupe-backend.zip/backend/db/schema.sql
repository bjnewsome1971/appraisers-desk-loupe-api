-- The Appraiser's Desk & Loupe — Database Schema (PostgreSQL)

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email           TEXT NOT NULL UNIQUE,
    password_hash   TEXT,                       -- null if using OAuth only
    display_name    TEXT,
    stripe_customer_id TEXT UNIQUE,              -- links to Stripe Customer object
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- MEMBERSHIP PLANS  (seed data, rarely changes)
-- ============================================================
CREATE TABLE plans (
    id                  TEXT PRIMARY KEY,        -- e.g. 'apprentice', 'journeyman', 'master'
    display_name        TEXT NOT NULL,
    monthly_price_cents INTEGER NOT NULL,
    monthly_id_limit    INTEGER,                 -- null = unlimited
    stripe_price_id     TEXT UNIQUE,              -- Stripe Price object for this plan
    features            JSONB NOT NULL DEFAULT '{}'::jsonb
);

INSERT INTO plans (id, display_name, monthly_price_cents, monthly_id_limit, features) VALUES
    ('apprentice', 'Apprentice', 0, 3, '{"history": false, "export": false}'),
    ('journeyman', 'Journeyman', 900, NULL, '{"history": true, "export": false}'),
    ('master', 'Master Appraiser', 2400, NULL, '{"history": true, "export": true, "priority_review": true}');

-- ============================================================
-- SUBSCRIPTIONS
-- One row per user's current/past subscription state, mirrors Stripe Subscription.
-- ============================================================
CREATE TABLE subscriptions (
    id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id                 UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    plan_id                 TEXT NOT NULL REFERENCES plans(id),
    stripe_subscription_id  TEXT UNIQUE,
    status                  TEXT NOT NULL CHECK (status IN
                                ('active','trialing','past_due','canceled','incomplete')),
    current_period_start    TIMESTAMPTZ,
    current_period_end      TIMESTAMPTZ,
    cancel_at_period_end    BOOLEAN NOT NULL DEFAULT false,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Fast lookup of a user's current plan
CREATE INDEX idx_subscriptions_user_status ON subscriptions(user_id, status);

-- ============================================================
-- IDENTIFICATIONS
-- One row per photo a member submits, covering both fine jewelry
-- and vintage signed costume jewelry (category distinguishes them).
-- ============================================================
CREATE TABLE identifications (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    mode                TEXT NOT NULL CHECK (mode IN ('fine', 'costume')),

    image_url           TEXT NOT NULL,           -- path in object storage (S3, etc.)

    category             TEXT,                    -- ring, brooch, necklace, etc.
    metal                TEXT,
    purity               TEXT,                    -- fine jewelry only
    gemstone             TEXT,
    estimated_carat      TEXT,                    -- fine jewelry only
    maker_signature       TEXT,                    -- costume jewelry only, e.g. "Trifari"
    hallmark             TEXT,
    style_era            TEXT,
    estimated_value_low  INTEGER,                 -- cents
    estimated_value_high INTEGER,                 -- cents
    overall_confidence   NUMERIC(3,2),             -- 0.00–1.00

    raw_model_response   JSONB NOT NULL,           -- full response, for reprocessing later
    created_at           TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_identifications_user_created ON identifications(user_id, created_at DESC);

-- ============================================================
-- MONTHLY USAGE COUNTER
-- Backs the free-tier identification limit without scanning identifications each time.
-- ============================================================
CREATE TABLE usage_counters (
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period_start    DATE NOT NULL,               -- first day of the billing month
    identification_count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, period_start)
);
